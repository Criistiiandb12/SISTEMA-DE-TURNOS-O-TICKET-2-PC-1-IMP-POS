
const express = require("express");
const PDFDocument = require("pdfkit");
const fs = require("fs");
const path = require("path");
const { print } = require("pdf-to-printer");
const cors  = require("cors"); 

const app = express();
app.use(cors());
app.use(express.json());

app.post("/print", async (req, res) => {
  const { turno } = req.body;

  if (!turno) {
    return res.status(400).json({ error: "Turno requerido" });
  }

  const filePath = path.join(__dirname, `ticket-${turno}.pdf`);

  const doc = new PDFDocument({
  size: [124, 160],
  margins: { top: 2, left: 6, right: 6, bottom: 2 }
});




  doc.pipe(fs.createWriteStream(filePath));


  doc.fontSize(12).text("TURNO", { align: "center" });
  doc.moveDown(0.5);
  doc.fontSize(20).text(turno, { align: "center" });
  doc.moveDown(0.5);
  doc.fontSize(8).text("Espere su llamado", { align: "center" });
  doc.fontSize(8).text(new Date().toLocaleString(), { align: "center" });

  doc.end();

  doc.on("end", async () => {
    try {
      await print(filePath, {
        silent: true,
        printDialog: false
      });

      fs.unlinkSync(filePath);
      res.json({ ok: true });
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: "Error al imprimir" });
    }
  });
});

app.listen(4000, () => {
  console.log("🖨 Printer server activo en http://localhost:4000");
});


